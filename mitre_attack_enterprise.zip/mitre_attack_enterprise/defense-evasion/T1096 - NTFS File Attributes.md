# T1096 NTFS File Attributes

