# T1144 Gatekeeper Bypass

