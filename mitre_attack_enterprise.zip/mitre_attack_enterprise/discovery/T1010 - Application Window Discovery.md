# T1010 Application Window Discovery

