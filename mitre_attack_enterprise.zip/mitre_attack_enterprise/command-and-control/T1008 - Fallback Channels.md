# T1008 Fallback Channels

