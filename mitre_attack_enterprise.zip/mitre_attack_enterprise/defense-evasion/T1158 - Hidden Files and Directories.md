# T1158 Hidden Files and Directories

