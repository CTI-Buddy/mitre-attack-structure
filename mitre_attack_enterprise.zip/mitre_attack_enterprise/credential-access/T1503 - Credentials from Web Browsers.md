# T1503 Credentials from Web Browsers

