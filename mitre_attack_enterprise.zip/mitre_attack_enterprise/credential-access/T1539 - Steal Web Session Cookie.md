# T1539 Steal Web Session Cookie

