# T1088 Bypass User Account Control

