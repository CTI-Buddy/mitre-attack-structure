# T1047 Windows Management Instrumentation

