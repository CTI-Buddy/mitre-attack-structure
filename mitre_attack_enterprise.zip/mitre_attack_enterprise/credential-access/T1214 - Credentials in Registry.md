# T1214 Credentials in Registry

