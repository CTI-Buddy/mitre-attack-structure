# T1092 Communication Through Removable Media

