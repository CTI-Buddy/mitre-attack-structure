# T1580 Cloud Infrastructure Discovery

