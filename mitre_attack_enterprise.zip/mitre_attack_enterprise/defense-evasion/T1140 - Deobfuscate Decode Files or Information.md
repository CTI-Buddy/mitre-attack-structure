# T1140 Deobfuscate Decode Files or Information

