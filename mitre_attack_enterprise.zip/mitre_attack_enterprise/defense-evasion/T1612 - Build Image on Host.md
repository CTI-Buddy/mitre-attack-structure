# T1612 Build Image on Host

