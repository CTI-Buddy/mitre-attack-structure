# T1185 Browser Session Hijacking

