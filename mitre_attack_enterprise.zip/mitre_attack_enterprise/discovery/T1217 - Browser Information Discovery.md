# T1217 Browser Information Discovery

