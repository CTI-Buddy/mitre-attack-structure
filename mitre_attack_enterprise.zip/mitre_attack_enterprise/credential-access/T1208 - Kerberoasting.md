# T1208 Kerberoasting

