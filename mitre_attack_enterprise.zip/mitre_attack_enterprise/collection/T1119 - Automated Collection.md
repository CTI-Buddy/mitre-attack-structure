# T1119 Automated Collection

