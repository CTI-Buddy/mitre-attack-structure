# T1049 System Network Connections Discovery

