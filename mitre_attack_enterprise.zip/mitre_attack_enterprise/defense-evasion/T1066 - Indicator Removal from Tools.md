# T1066 Indicator Removal from Tools

