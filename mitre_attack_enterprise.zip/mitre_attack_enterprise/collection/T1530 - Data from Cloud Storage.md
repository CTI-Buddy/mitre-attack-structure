# T1530 Data from Cloud Storage

