# T1082 System Information Discovery

