# T1120 Peripheral Device Discovery

