# T1528 Steal Application Access Token

