# T1146 Clear Command History

