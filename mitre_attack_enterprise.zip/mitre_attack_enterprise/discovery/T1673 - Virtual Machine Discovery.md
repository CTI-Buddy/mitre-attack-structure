# T1673 Virtual Machine Discovery

