# T1112 Modify Registry

