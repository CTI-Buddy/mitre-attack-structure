# T1122 Component Object Model Hijacking

