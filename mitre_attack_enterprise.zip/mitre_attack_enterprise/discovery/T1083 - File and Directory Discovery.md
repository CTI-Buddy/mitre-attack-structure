# T1083 File and Directory Discovery

