# T1005 Data from Local System

