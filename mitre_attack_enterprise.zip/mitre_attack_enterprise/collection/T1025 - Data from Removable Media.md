# T1025 Data from Removable Media

