# T1482 Domain Trust Discovery

