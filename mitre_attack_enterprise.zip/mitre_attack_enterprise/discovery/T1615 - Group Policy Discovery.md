# T1615 Group Policy Discovery

